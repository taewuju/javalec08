package repository.impl;

public class DBRepository {

}
