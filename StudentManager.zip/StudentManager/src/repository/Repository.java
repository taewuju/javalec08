package repository;

public interface Repository {

}
