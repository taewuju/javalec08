import controller.ManagerController;

public class MyApp {

	public static void main(String args[]) {
		ManagerController controller = new ManagerController();
		controller.systemStart();
	}
	
}
