package service;

public interface ManagerService {

}
