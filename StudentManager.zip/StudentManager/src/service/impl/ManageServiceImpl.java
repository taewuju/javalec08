package service.impl;

public class ManageServiceImpl {

}
