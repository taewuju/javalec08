

import controller.StudentManagerController;

public class MyApp {
	
	public static void main(String args[]) throws Exception {

		StudentManagerController controller = new StudentManagerController();
		controller.systemStart();
		
	}
	
}
